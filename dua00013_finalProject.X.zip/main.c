#include "xc.h"
#include "led.h"

#pragma config ICS = PGx1
#pragma config FWDTEN = OFF
#pragma config GWRP = OFF
#pragma config GCP = OFF
#pragma config JTAGEN = OFF

#pragma config I2C1SEL = PRI
#pragma config IOL1WAY = OFF
#pragma config OSCIOFNC = ON
#pragma config FCKSM = CSECME
#pragma config FNOSC = FRCPLL

void setup(void)
{
    CLKDIVbits.RCDIV = 0;

    AD1PCFG = 0x9FFF;

    _I2CEN = 0;
    I2C1BRG = 157;          // 100 kHz at Fcy = 16 MHz
    IFS1bits.MI2C1IF = 0;
    _I2CEN = 1;
}

int main(void)
{
    setup();

    led_init();

    while (1)
    {
        // All LEDs on
        LATBbits.LATB5 = 1;
        led_allOn();
        delay_ms(50);

        // All LEDs off
        LATBbits.LATB5 = 0;
        led_allOff();
        delay_ms(50);

        // Diagonal test
        LATBbits.LATB5 = 1;
        led_diagonal();
        delay_ms(50);

        // Border test
        LATBbits.LATB5 = 0;
        led_border();
        delay_ms(50);

        // Checkerboard test
        LATBbits.LATB5 = 1;
        led_checkerboard();
        delay_ms(50);

        // Clear before repeat
        LATBbits.LATB5 = 0;
        led_allOff();
        delay_ms(50);
    }


    return 0;
}