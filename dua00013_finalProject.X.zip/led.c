/*
 * File:   led.c
 * Author: Mohak Dua
 *
 * Created on April 29, 2026, 4:57 PM
 */


#include "xc.h"
#include "led.h"

static uint8_t led_buffer[LED_HEIGHT];

void delay_ms(uint32_t ms) {
    while (ms-- > 0) {
        asm("repeat #15998");
        asm("nop");
    }
}

void led_i2c_start(void) {
    I2C1CONbits.SEN = 1;
    while (I2C1CONbits.SEN);
}

void led_i2c_stop(void) {
    I2C1CONbits.PEN = 1;
    while (I2C1CONbits.PEN);
}

void led_i2c_write(uint8_t data) {
    _MI2C1IF = 0;
    I2C1TRN = data;
    while (!_MI2C1IF);
    _MI2C1IF = 0;
}

void led_cmd(uint8_t command)
{
    led_i2c_start();

    led_i2c_write(LED_I2C_WRITE_ADDR);
    led_i2c_write(command);

    led_i2c_stop();
}

void led_writeDisplay(void)
{
    led_i2c_start();

    led_i2c_write(LED_I2C_WRITE_ADDR);
    led_i2c_write(LED_DISPLAY_RAM_ADDR);

    for (uint8_t row = 0; row < LED_HEIGHT; row++)
    {
        led_i2c_write(led_buffer[row]);
        led_i2c_write(0x00);
    }

    led_i2c_stop();
}

void led_init(void)
{
    delay_ms(10);

    led_cmd(LED_OSCILLATOR_ON);
    led_cmd(LED_DISPLAY_ON);
    led_setBrightness(4);

    led_clear();
    led_writeDisplay();
}

void led_clear(void)
{
    for (uint8_t row = 0; row < LED_HEIGHT; row++)
    {
        led_buffer[row] = 0x00;
    }
}

void led_fill(void)
{
    for (uint8_t row = 0; row < LED_HEIGHT; row++)
    {
        led_buffer[row] = 0xFF;
    }
}

void led_setBrightness(uint8_t brightness)
{
    if (brightness > 15)
    {
        brightness = 15;
    }

    led_cmd(LED_BRIGHTNESS_BASE | brightness);
}

void led_drawPixel(uint8_t x, uint8_t y, uint8_t on)
{
    if (x >= LED_WIDTH || y >= LED_HEIGHT)
    {
        return;
    }

    uint8_t fixed_x = 7 - x;
    uint8_t mapped_x = (fixed_x + 7) % 8;

    if (on)
    {
        led_buffer[y] |= (1 << mapped_x);
    }
    else
    {
        led_buffer[y] &= ~(1 << mapped_x);
    }
}

void led_setRow(uint8_t row, uint8_t value)
{
    if (row >= LED_HEIGHT)
    {
        return;
    }

    led_buffer[row] = value;
}

// Demos

void led_allOn(void)
{
    led_fill();
    led_writeDisplay();
}

void led_allOff(void)
{
    led_clear();
    led_writeDisplay();
}

void led_diagonal(void)
{
    led_clear();

    for (uint8_t i = 0; i < 8; i++)
    {
        led_drawPixel(i, i, 1);
    }

    led_writeDisplay();
}

void led_border(void)
{
    led_clear();

    for (uint8_t x = 0; x < 8; x++)
    {
        led_drawPixel(x, 0, 1);
        led_drawPixel(x, 7, 1);
    }

    for (uint8_t y = 0; y < 8; y++)
    {
        led_drawPixel(0, y, 1);
        led_drawPixel(7, y, 1);
    }

    led_writeDisplay();
}

void led_checkerboard(void)
{
    led_clear();

    for (uint8_t y = 0; y < 8; y++)
    {
        for (uint8_t x = 0; x < 8; x++)
        {
            if ((x + y) % 2)
            {
                led_drawPixel(x, y, 1);
            }
        }
    }

    led_writeDisplay();
}


void led_rowTest(void)
{
    for (uint8_t row = 0; row < 8; row++)
    {
        led_clear();
        led_buffer[row] = 0x80;
        led_writeDisplay();
        delay_ms(1000);
    }
}